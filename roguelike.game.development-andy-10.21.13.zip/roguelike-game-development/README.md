#Rogue-Like 2D in Java

[![Build Status](https://travis-ci.org/Open-Horizons/roguelike-game-development.png?branch=master)](https://travis-ci.org/Open-Horizons/roguelike-game-development)

####View:
*Top-Down*
####Theme:
*Fantasy we may add some future to it as well*
####Scenerio:
*Freeplay / RPG / Quest-Based*
####Main Idea:
[Example: ](https://lh3.ggpht.com/-bEYiBpVQ5nU/UP6nJvAh7QI/AAAAAAAADSE/q7mQ7IgLEZE/s1600/33.png)

[See the wiki for contents and ideas](https://github.com/Open-Horizons/roguelike-game-development/wiki)
