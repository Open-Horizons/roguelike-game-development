/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package roguelike_game.entity;

/**
 *
 * @author andyafw
 */
public class RaceType {
    public static RaceType ORC        = new RaceType();
    public static RaceType GOBLIN     = new RaceType();
    public static RaceType GNOME      = new RaceType();
    public static RaceType HUMAN      = new RaceType();
    public static RaceType ELF        = new RaceType();
    public static RaceType BLOODELF   = new RaceType();
    public static RaceType CATPERSON  = new RaceType();
    public static RaceType HALFDRAGON = new RaceType();
    public static RaceType FISHMAN    = new RaceType();
    public static RaceType HALFLING   = new RaceType();
    public static RaceType UNDEAD     = new RaceType();
    public static RaceType VAMPIRE    = new RaceType();
    public static RaceType LIZARDMAN  = new RaceType();
    
    public RaceType() {
        
    }
}
