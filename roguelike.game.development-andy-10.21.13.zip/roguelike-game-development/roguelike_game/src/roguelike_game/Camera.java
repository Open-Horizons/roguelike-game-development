/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package roguelike_game;

/**
 *
 * @author andyafw
 */
public class Camera {
    public int x, y;
    
    public Camera() {
        x = 0;
        y = 0;
    }
}
